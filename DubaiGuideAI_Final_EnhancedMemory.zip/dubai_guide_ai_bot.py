
import logging
import os
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes, MessageHandler, filters

from utils.memory import MemoryManager
from utils.response_logic import generate_reply

logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)

memory_manager = MemoryManager()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    memory_manager.reset_memory(update.effective_user.id)
    welcome = "👋 Hello and welcome to Dubai Guide AI! 🌟 I’m your personal travel assistant for everything Dubai. Ask me about places to visit, food to try, transportation tips, or anything else you’re curious about. 🏖️✈️"
    await update.message.reply_text(welcome)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    user_input = update.message.text

    memory_manager.add_to_memory(user_id, user_input)
    recent_context = memory_manager.get_context(user_id)

    reply = generate_reply(user_input, recent_context)
    await update.message.reply_text(reply)

def main() -> None:
    token = os.getenv("TELEGRAM_TOKEN")
    app = ApplicationBuilder().token(token).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    app.run_polling()

if __name__ == "__main__":
    main()
    