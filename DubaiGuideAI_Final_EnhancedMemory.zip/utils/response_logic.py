
def generate_reply(user_input, context):
    input_lower = user_input.lower()

    if "weather" in input_lower:
        return "☀️ The weather in Dubai is usually sunny and warm. Summer highs can reach 45°C, while winter is mild and perfect for sightseeing."

    if "3 day trip" in input_lower or "plan" in input_lower:
        return ("📅 Here’s a 3-day Dubai itinerary:

"
                "Day 1: Burj Khalifa, Dubai Mall & Fountain Show
"
                "Day 2: Dubai Marina, JBR Beach, Desert Safari
"
                "Day 3: Old Dubai, Gold Souk, Dubai Frame")

    if "restaurant" in input_lower or "food" in input_lower:
        return "🍽️ Dubai has amazing cuisine! Try Ravi’s for Pakistani food, Rang Mahal for Indian, or Al Fanar for Emirati dishes."

    if "hotel" in input_lower or "budget" in input_lower:
        return "🏨 Some great budget hotels near Dubai Mall include Rove Downtown, Citymax Hotel, and Ibis World Trade Centre."

    if "safe" in input_lower and "women" in input_lower:
        return ("👩 Dubai is one of the safest cities for women. Crime is low and tourists are generally respected, "
                "but like any city, it’s best to stay alert at night.")

    if "cost" in input_lower or "price" in input_lower:
        return "💰 Can you tell me what you want the price for—hotels, food, attractions? I’d love to help!"

    return "🤖 I'm here to help with anything about Dubai! Could you clarify your question a little more so I can give you a better answer?"
    