
class MemoryManager:
    def __init__(self):
        self.user_memory = {}

    def reset_memory(self, user_id):
        self.user_memory[user_id] = []

    def add_to_memory(self, user_id, message):
        if user_id not in self.user_memory:
            self.user_memory[user_id] = []
        self.user_memory[user_id].append(message)
        if len(self.user_memory[user_id]) > 3:
            self.user_memory[user_id] = self.user_memory[user_id][-3:]

    def get_context(self, user_id):
        return " ".join(self.user_memory.get(user_id, []))
    